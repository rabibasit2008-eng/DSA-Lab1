#include <iostream>
#include <string>
using namespace std;

struct Student {
    int studentID;
    string name;
    float GPA;
    Student* left;
    Student* right;

    Student(int id, string n, float g) {
        studentID = id;
        name = n;
        GPA = g;
        left = right = nullptr;
    }
};

// Insert student
Student* insert(Student* root, int id, string name, float gpa) {
    if (root == nullptr)
        return new Student(id, name, gpa);

    if (id < root->studentID)
        root->left = insert(root->left, id, name, gpa);
    else if (id > root->studentID)
        root->right = insert(root->right, id, name, gpa);
    else
        cout << "Student ID already exists.\n";

    return root;
}

// Search student by ID
Student* search(Student* root, int id) {
    if (root == nullptr || root->studentID == id)
        return root;

    if (id < root->studentID)
        return search(root->left, id);

    return search(root->right, id);
}

// Display one student
void displayStudent(Student* s) {
    if (s == nullptr) {
        cout << "Student not found.\n";
        return;
    }

    cout << "ID: " << s->studentID
         << ", Name: " << s->name
         << ", GPA: " << s->GPA << endl;
}

// Find smallest ID in a subtree
Student* findMin(Student* root) {
    while (root != nullptr && root->left != nullptr)
        root = root->left;

    return root;
}

// Delete student by ID
Student* deleteStudent(Student* root, int id) {
    if (root == nullptr)
        return nullptr;

    if (id < root->studentID) {
        root->left = deleteStudent(root->left, id);
    }
    else if (id > root->studentID) {
        root->right = deleteStudent(root->right, id);
    }
    else {
        // No left child
        if (root->left == nullptr) {
            Student* temp = root->right;
            delete root;
            return temp;
        }

        // No right child
        if (root->right == nullptr) {
            Student* temp = root->left;
            delete root;
            return temp;
        }

        // Two children
        Student* temp = findMin(root->right);

        root->studentID = temp->studentID;
        root->name = temp->name;
        root->GPA = temp->GPA;

        root->right = deleteStudent(root->right,
                                    temp->studentID);
    }

    return root;
}

// Inorder traversal: students sorted by ID
void inorder(Student* root) {
    if (root == nullptr) return;

    inorder(root->left);
    displayStudent(root);
    inorder(root->right);
}

// Count total students
int countStudents(Student* root) {
    if (root == nullptr) return 0;

    return 1 + countStudents(root->left)
             + countStudents(root->right);
}

// Find highest and lowest GPA
void findGPAs(Student* root, Student*& highest,
              Student*& lowest) {
    if (root == nullptr) return;

    if (highest == nullptr || root->GPA > highest->GPA)
        highest = root;

    if (lowest == nullptr || root->GPA < lowest->GPA)
        lowest = root;

    findGPAs(root->left, highest, lowest);
    findGPAs(root->right, highest, lowest);
}

// Display students above a GPA threshold
void displayAboveGPA(Student* root, float threshold) {
    if (root == nullptr) return;

    displayAboveGPA(root->left, threshold);

    if (root->GPA > threshold)
        displayStudent(root);

    displayAboveGPA(root->right, threshold);
}

int main() {
    Student* root = nullptr;

    // Insert sample records
    root = insert(root, 103, "Ali", 3.5);
    root = insert(root, 101, "Ahmed", 3.8);
    root = insert(root, 105, "Sara", 3.9);
    root = insert(root, 102, "Usman", 2.9);
    root = insert(root, 104, "Ayesha", 3.2);

    int choice;

    do {
        cout << "\n--- Student Record System ---\n";
        cout << "1. Insert student\n";
        cout << "2. Search student\n";
        cout << "3. Delete student\n";
        cout << "4. Display all students\n";
        cout << "5. Count students\n";
        cout << "6. Highest and lowest GPA\n";
        cout << "7. Display students above GPA\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            int id;
            string name;
            float gpa;

            cout << "Enter ID: ";
            cin >> id;

            cout << "Enter name (one word): ";
            cin >> name;

            cout << "Enter GPA: ";
            cin >> gpa;

            if (gpa < 0 || gpa > 4) {
                cout << "Invalid GPA. Use 0 to 4.\n";
            } else {
                Student* existing = search(root, id);

                if (existing != nullptr)
                    cout << "Student ID already exists.\n";
                else {
                    root = insert(root, id, name, gpa);
                    cout << "Student added.\n";
                }
            }
        }
        else if (choice == 2) {
            int id;
            cout << "Enter student ID: ";
            cin >> id;

            displayStudent(search(root, id));
        }
        else if (choice == 3) {
            int id;
            cout << "Enter student ID to delete: ";
            cin >> id;

            if (search(root, id) == nullptr)
                cout << "Student not found.\n";
            else {
                root = deleteStudent(root, id);
                cout << "Student deleted.\n";
            }
        }
        else if (choice == 4) {
            cout << "\nStudents sorted by ID:\n";
            inorder(root);
        }
        else if (choice == 5) {
            cout << "Total students: "
                 << countStudents(root) << endl;
        }
        else if (choice == 6) {
            Student* highest = nullptr;
            Student* lowest = nullptr;

            findGPAs(root, highest, lowest);

            if (root == nullptr) {
                cout << "No student records available.\n";
            } else {
                cout << "Highest GPA:\n";
                displayStudent(highest);

                cout << "Lowest GPA:\n";
                displayStudent(lowest);
            }
        }
        else if (choice == 7) {
            float threshold;

            cout << "Enter GPA threshold: ";
            cin >> threshold;

            cout << "Students above " << threshold << ":\n";
            displayAboveGPA(root, threshold);
        }
        else if (choice != 0) {
            cout << "Invalid choice.\n";
        }

    } while (choice != 0);

    return 0;
}
