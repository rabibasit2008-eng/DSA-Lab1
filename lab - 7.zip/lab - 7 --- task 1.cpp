#include <iostream>
#include <stack>
#include <string>
using namespace std;

struct Node {
    char data;
    Node* left;
    Node* right;

    Node(char value) {
        data = value;
        left = right = nullptr;
    }
};

Node* buildTree(string s, int& i) {
    if (i >= s.length() || s[i] == ',' || s[i] == ')')
        return nullptr;

    Node* root = new Node(s[i]);
    i++;

    if (i < s.length() && s[i] == '(') {
        i++;

        root->left = buildTree(s, i);

        if (i < s.length() && s[i] == ',')
            i++;

        root->right = buildTree(s, i);

        if (i < s.length() && s[i] == ')')
            i++;
    }

    return root;
}
// 2. Recursive preorder
void preorder(Node* root) {
    if (root == nullptr) return;

    cout << root->data << " ";
    preorder(root->left);
    preorder(root->right);
}
// 3. Iterative inorder using stack
void inorder(Node* root) {
    stack<Node*> s;
    Node* temp = root;

    while (temp != nullptr || !s.empty()) {
        while (temp != nullptr) {
            s.push(temp);
            temp = temp->left;
        }

        temp = s.top();
        s.pop();

        cout << temp->data << " ";
        temp = temp->right;
    }
}

// 4. Iterative postorder using two stacks
void postorder(Node* root) {
    if (root == nullptr) return;

    stack<Node*> s1, s2;
    s1.push(root);

    while (!s1.empty()) {
        Node* temp = s1.top();
        s1.pop();
        s2.push(temp);

        if (temp->left != nullptr)
            s1.push(temp->left);

        if (temp->right != nullptr)
            s1.push(temp->right);
    }

    while (!s2.empty()) {
        cout << s2.top()->data << " ";
        s2.pop();
    }
}

// 5. Validate string without building a tree
bool validate(string s, int& i) {
    if (i >= s.length() ||
        s[i] == ',' || s[i] == ')')
        return false;

    i++; // Read node

    if (i < s.length() && s[i] == '(') {
        i++;

        // Left child may be empty
        if (i < s.length() && s[i] != ',') {
            if (!validate(s, i))
                return false;
        }

        if (i >= s.length() || s[i] != ',')
            return false;

        i++;

        // Right child may be empty
        if (i < s.length() && s[i] != ')') {
            if (!validate(s, i))
                return false;
        }

        if (i >= s.length() || s[i] != ')')
            return false;

        i++;
    }

    return true;
}

bool isValid(string s) {
    if (s.empty()) return false;

    int i = 0;
    return validate(s, i) && i == s.length();
}

// 6. Calculate height
int height(Node* root) {
    if (root == nullptr) return 0;

    int leftHeight = height(root->left);
    int rightHeight = height(root->right);

    return 1 + max(leftHeight, rightHeight);
}

// Display depth of each node
void displayDepth(Node* root, int depth) {
    if (root == nullptr) return;

    cout << root->data << " : " << depth << endl;

    displayDepth(root->left, depth + 1);
    displayDepth(root->right, depth + 1);
}

// 7. BST using integers
struct BSTNode {
    int data;
    BSTNode* left;
    BSTNode* right;

    BSTNode(int value) {
        data = value;
        left = right = nullptr;
    }
};

BSTNode* insertBST(BSTNode* root, int value) {
    if (root == nullptr)
        return new BSTNode(value);

    if (value < root->data)
        root->left = insertBST(root->left, value);
    else if (value > root->data)
        root->right = insertBST(root->right, value);

    return root;
}

void inorderBST(BSTNode* root) {
    if (root == nullptr) return;

    inorderBST(root->left);
    cout << root->data << " ";
    inorderBST(root->right);
}

int main() {
    string s = "a(b(d,e),c(,f(g,)))";

    int i = 0;
    Node* root = buildTree(s, i);

    cout << "Preorder: ";
    preorder(root);

    cout << "\nInorder: ";
    inorder(root);

    cout << "\nPostorder: ";
    postorder(root);

    cout << "\n\nValid tree string: ";
    cout << (isValid(s) ? "Yes" : "No");

    cout << "\nHeight: " << height(root);

    cout << "\nDepth of each node:\n";
    displayDepth(root, 0);

    int values[] = {50, 30, 70, 20, 40, 60, 80};
    BSTNode* bst = nullptr;

    for (int value : values)
        bst = insertBST(bst, value);

    cout << "\nBST Inorder: ";
    inorderBST(bst);

    cout << endl;
    return 0;
}
