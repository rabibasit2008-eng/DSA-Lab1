#include <iostream>
#include <string>
#include <cctype>
using namespace std;
// Character Stack
struct CharNode{
    char data;
    CharNode* next;
};

class CharStack{
private:
    CharNode* topNode;
public:
    CharStack(){
        topNode = NULL;
    }
    void push(char c){
        CharNode* newNode = new CharNode;

        newNode->data = c;
        newNode->next = topNode;
        topNode = newNode;
    }
    char pop(){
        if (isEmpty())
            return '\0';

        CharNode* temp = topNode;
        char value = temp->data;

        topNode = topNode->next;
        delete temp;
        return value;
    }

    char top(){
        if (isEmpty())
            return '\0';

        return topNode->data;
    }

    bool isEmpty(){
        return topNode == NULL;
    }
    void clearStack(){
        while (topNode != NULL){
            CharNode* temp = topNode;
            topNode = topNode->next;
            delete temp;
        }
    }
    ~CharStack(){
        clearStack();
    }
};
// Integer Stack
struct IntNode{
    int data;
    IntNode* next;
};

class IntStack{
private:
    IntNode* topNode;
public:
    IntStack(){
        topNode = NULL;
    }
    void push(int value){
        IntNode* newNode = new IntNode;

        newNode->data = value;
        newNode->next = topNode;

        topNode = newNode;
    }
    int pop(){
        if (isEmpty())
            return 0;

        IntNode* temp = topNode;
        int value = temp->data;

        topNode = topNode->next;
        delete temp;
        return value;
    }
    bool isEmpty(){
        return topNode == NULL;
    }

    void clearStack(){
        while (topNode != NULL){
            IntNode* temp = topNode;
            topNode = topNode->next;
            delete temp;
        }
    }
    ~IntStack(){
        clearStack();
    }
};
// Check whether character is an operator
bool isOperator(char ch){
    return ch == '+' || ch == '-' ||
           ch == '*' || ch == '/' ||
           ch == '%';
}
// Determine precedence
int precedence(char ch){
    if (ch == '+' || ch == '-')
        return 1;

    if (ch == '*' || ch == '/' || ch == '%')
        return 2;

    return 0;
}
// Infix to Postfix
string infixToPostfix(string expression, bool& valid){
    CharStack operators;
    string postfix = "";

    valid = true;
    if (expression.empty()){
        valid = false;
        return "";
    }
    for (int i = 0; i < expression.length(); i++){
        char ch = expression[i];
        // Ignore spaces
        if (ch == ' ')
            continue;
        // Operand
        if (isdigit(ch)){
            postfix += ch;
            postfix += ' ';
        }
        // Opening parenthesis
        else if (ch == '('){
            operators.push(ch);
        }
        // Closing parenthesis
        else if (ch == ')'){
            bool foundOpening = false;

            while (!operators.isEmpty()){
                char op = operators.pop();
                if (op == '('){
                    foundOpening = true;
                    break;
                }
                postfix += op;
                postfix += ' ';
            }
            if (!foundOpening){
                valid = false;
                return "";
            }
        }
        // Operator
        else if (isOperator(ch)){
            while (!operators.isEmpty() &&
                   operators.top() != '(' &&
                   precedence(operators.top()) >= precedence(ch)){
                postfix += operators.pop();
                postfix += ' ';
            }
            operators.push(ch);
        }
        // Invalid character
        else{
            valid = false;
            return "";
        }
    }
    // Empty stack
    while (!operators.isEmpty()){
        char op = operators.pop();
        // Mismatched parenthesis
        if (op == '('){
            valid = false;
            return "";
        }
        postfix += op;
        postfix += ' ';
    }
    return postfix;
}
// Evaluate postfix expression
int evaluatePostfix(string postfix, bool& valid){
    IntStack numbers;
    valid = true;
    for (int i = 0; i < postfix.length(); i++){
        char ch = postfix[i];
        // Operand
        if (isdigit(ch)){
            numbers.push(ch - '0');
        }
        // Operator
        else if (isOperator(ch)){
            if (numbers.isEmpty()){
                valid = false;
                return 0;
            }
            int b = numbers.pop();
            if (numbers.isEmpty()){
                valid = false;
                return 0;
            }
            int a = numbers.pop();
            int result = 0;
            if (ch == '+')
                result = a + b;
            else if (ch == '-')
                result = a - b;

            else if (ch == '*')
                result = a * b;

            else if (ch == '/'){
                if (b == 0){
                    cout << "Error: Division by zero." << endl;
                    valid = false;
                    return 0;
                }
                result = a / b;
            }
            else if (ch == '%'){
                if (b == 0){
                    cout << "Error: Division by zero." << endl;
                    valid = false;
                    return 0;
                }
                result = a % b;
            }
            numbers.push(result);
        }
    }
    if (numbers.isEmpty()){
        valid = false;
        return 0;
    }
    int answer = numbers.pop();
    // There should be only one final result
    if (!numbers.isEmpty()){
        valid = false;
        return 0;
    }
    return answer;
}
int main(){
    string expressions[] =
    {
        "2 + 3 * 4",
        "(2 + 3) * 4",
        "10 + 2 * 6",
        "(10 + 2) * (6 - 3)",
        "20 / 5 + 3",
        "2 * (3 + (4 * 5))",
        "10 + 5 * 2 - 3",
        "",
        "(2 + 3",
        "10 / 0"
    };
    int size = 10;
    for (int i = 0; i < size; i++){
        cout << "\nExpression: " << expressions[i] << endl;
        bool valid;
        string postfix = infixToPostfix(expressions[i], valid);
        if (!valid){
            cout << "Invalid expression." << endl;
            continue;
        }
        cout << "Postfix: " << postfix << endl;
        int result = evaluatePostfix(postfix, valid);
        if (valid)
            cout << "Result: " << result << endl;
        else
            cout << "Could not evaluate expression." << endl;
    }
    return 0;
}