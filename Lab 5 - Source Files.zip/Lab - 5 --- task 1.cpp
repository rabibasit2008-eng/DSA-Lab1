#include <iostream>
using namespace std;

struct Node{
    char data;
    Node *next;
};

class Stack{
    private:
        Node *topNode;

    public:
    Stack(){
        topNode = NULL;
    }
    void push(char c){
        Node *newNode = new Node;
        newNode->data = c;
        newNode->next = topNode;
        topNode = newNode;
    }
    char pop(){
        if(isEmpty()){
            return '\0';
        }
        Node *temp = topNode;
        char ch = temp->data;

        topNode = topNode->next;
        delete temp;
        return ch;
    }
    char top(){
        if(isEmpty()){
            return '\0';
        }
        return topNode->data;
    }
    bool isEmpty(){
        return topNode == NULL;
    }

    bool checkBalance(string expression){
        clearStack();

        for (int i = 0; i < expression.length(); i++){
            char ch = expression[i];
            // Opening brackets
            if (ch == '(' || ch == '[' || ch == '{'){
                push(ch);
            }
            // Closing brackets
            else if (ch == ')' || ch == ']' || ch == '}'){
                // Extra closing bracket
                if (isEmpty())
                    return false;
                char open = pop();
                // Check matching brackets
                if (ch == ')' && open != '(')
                    return false;

                if (ch == ']' && open != '[')
                    return false;

                if (ch == '}' && open != '{')
                    return false;
            }
        }
        return isEmpty();
    }

    void displayStack(){
        if(isEmpty()){
            cout << "Stack is Empty." << endl;
            return;
        }
        Node *temp = topNode;

        while(temp != NULL){
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    void clearStack(){
        while(topNode != NULL){
            Node *temp = topNode;
            topNode = topNode->next;
            delete temp;
        }
    }
    //destructor
    ~Stack(){
        clearStack();
    }
};

int main(){
    Stack s;
    string expressions[] = {
        "(A+B)",
        "{A+[B*C]}",
        "(A+B]",
        "((A+B)",
        "{[()]}",
        "A+B*C",
        "([A+B])"};

    int size = 7;
    for (int i = 0; i < size; i++){
        cout << expressions[i] << " -> " ;
        if (s.checkBalance(expressions[i])) cout << "Balanced" << endl;
        else cout << "Not Balanced" << endl;
    }
    return 0;
}