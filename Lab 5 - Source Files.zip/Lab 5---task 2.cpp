#include <iostream>
#include <string>
using namespace std;

struct Node
{
    int jobID;
    string document;
    int pages;
    Node* next;
};
class Queue{
private:
    Node* front;
    Node* rear;

public:
    Queue(){
        front = NULL;
        rear = NULL;
    }
    // 1. Add Job
    void addJob(int id, string doc, int p){
        Node* newNode = new Node;

        newNode->jobID = id;
        newNode->document = doc;
        newNode->pages = p;
        newNode->next = NULL;
        // If queue is empty
        if (isEmpty()){
            front = rear = newNode;
        }
        else{
            rear->next = newNode;
            rear = newNode;
        }
    }
    // 2. Process Job
    void processJob(){
        if (isEmpty()){
            cout << "Queue is empty. No job to process." << endl;
            return;
        }
        Node* temp = front;
        cout << "Processing Job: "
             << temp->jobID << " | "
             << temp->document << " | "
             << temp->pages << " pages" << endl;

        front = front->next;

        // If last job was removed
        if (front == NULL){
            rear = NULL;
        }
        delete temp;
    }
    // 3. View Next Job
    void viewNextJob(){
        if (isEmpty())
        {
            cout << "Queue is empty." << endl;
            return;
        }
        cout << "Next Job: "
             << front->jobID << " | "
             << front->document << " | "
             << front->pages << " pages" << endl;
    }
    // 4. Display Queue
    void displayQueue(){
        if (isEmpty()){
            cout << "Queue is empty." << endl;
            return;
        }
        Node* temp = front;
        cout << "\nWaiting Jobs:\n";
        while (temp != NULL){
            cout << "Job ID: " << temp->jobID
                 << " | Document: " << temp->document
                 << " | Pages: " << temp->pages << endl;

            temp = temp->next;
        }
    }
    // 5. Count Jobs
    int countJobs(){
        int count = 0;
        Node* temp = front;

        while (temp != NULL){
            count++;
            temp = temp->next;
        }
        return count;
    }
    // 6. IsEmpty
    bool isEmpty(){
        return front == NULL;
    }
    // 7. Clear Queue
    void clearQueue(){
        while (front != NULL){
            Node* temp = front;
            front = front->next;
            delete temp;
        }
        rear = NULL;
    }
    // Destructor
    ~Queue(){
        clearQueue();
    }
};
int main(){
    Queue q;
    // Add jobs
    q.addJob(101, "Assignment1.pdf", 10);
    q.addJob(102, "Report.docx", 25);
    q.addJob(103, "Notes.pdf", 5);
    q.addJob(104, "LabTask.docx", 15);

    // 1. Display all jobs
    cout << "1. All Jobs:";
    q.displayQueue();

    // 2. Process two jobs
    cout << "\n2. Processing Two Jobs:\n";
    q.processJob();
    q.processJob();

    // 3. Display remaining jobs
    cout << "\n3. Remaining Jobs:";
    q.displayQueue();

    // 4. Add a new job
    cout << "\n4. Adding New Job:\n";
    q.addJob(105, "Project.pdf", 20);

    // 5. Display next job
    cout << "\n5. Next Job:\n";
    q.viewNextJob();

    // Count jobs
    cout << "\nNumber of waiting jobs: "
         << q.countJobs() << endl;

    // 6. Process all remaining jobs
    cout << "\n6. Processing Remaining Jobs:\n";

    while (!q.isEmpty())
    {
        q.processJob();
    }

    // 7. Attempt to process from empty queue
    cout << "\n7. Attempting to process empty queue:\n";
    q.processJob();

    return 0;
}