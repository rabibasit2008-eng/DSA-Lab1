#include <iostream>
using namespace std;

void inputSortedIDs(int arr[], int n) {
    cout << "Enter the registration IDs in ascending order:" << endl;

    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
}

bool isSorted(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        if (arr[i] > arr[i + 1]) {
            return false;
        }
    }
    return true;
}

int binarySearch(int arr[], int low, int high, int target) {
    while (low <= high) {
        int mid = low + (high - low) / 2;

        if (arr[mid] == target) {
            return mid;
        }
        else if (target < arr[mid]) {
            high = mid - 1;
        }
        else {
            low = mid + 1;
        }
    }
    return -1;
}

int main() {
    int n;

    cout << "Enter the number of students: ";
    cin >> n;
    if (n < 0) {
        cout << "Invalid array size." << endl;
        return 0;
    }

    int* arr = new int[n];
    inputSortedIDs(arr, n);
    if (!isSorted(arr, n)) {
        cout << "Error: IDs are not sorted in ascending order." << endl;
        delete[] arr;
        return 0;
    }
    int target;
    cout << "Enter the registration number to search: ";
    cin >> target;
    int index = binarySearch(arr, 0, n - 1, target);
    if (index != -1) {
        cout << "Found at index " << index << endl;
    }
    else {
        cout << "Registration number not found." << endl;
    }
    delete[] arr;
    return 0;
}
