#include <iostream>
using namespace std;

void inputIDs(int arr[], int n) {
    cout << "Enter the student IDs:" << endl;

    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
}

int linearSearch(int arr[], int n, int target) {
    for (int i = 0; i < n; i++) {
        if (arr[i] == target) {
            return i;
        }
    }
    return -1;
}

void displayResult(int index) {
    if (index != -1) { cout << "Student ID found at index: " << index << endl;}
    else {  cout << "Student ID is not registered." << endl;    }
}

int main() {
    int n;

    cout << "Enter the number of students: ";
    cin >> n;

    if (n < 0) {
        cout << "Invalid array size." << endl;
        return 0;
    }

    int* arr = new int[n];

    inputIDs(arr, n);

    int target;
    cout << "Enter the target student ID: ";
    cin >> target;
    int index = linearSearch(arr, n, target);
    displayResult(index);
    
    delete[] arr;

    return 0;
}
