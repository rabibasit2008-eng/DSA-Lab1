#include <iostream>
using namespace std;

const int MAX = 20;

int board[MAX][MAX];
int N;

int dx[8] = {-2, -2, -1, -1, 1, 1, 2, 2};
int dy[8] = {-1, 1, -2, 2, -2, 2, -1, 1};

bool isSafe(int row, int col) {
    return row >= 0 && row < N &&
           col >= 0 && col < N &&
           board[row][col] == -1;
}

bool solveKnightTour(int row, int col, int moveNumber) {

    // Base case: all squares have been visited
    if (moveNumber == N * N)
        return true;

    // Try all eight possible moves
    for (int i = 0; i < 8; i++) {

        int nextRow = row + dx[i];
        int nextCol = col + dy[i];

        if (isSafe(nextRow, nextCol)) {
            // Mark the next square
            board[nextRow][nextCol] = moveNumber + 1;
            // Recursively search for a complete tour
            if (solveKnightTour(nextRow, nextCol,
                                moveNumber + 1))
                return true;

            // Backtrack if the move fails
            board[nextRow][nextCol] = -1;
        }
    }
    return false;
}

int main() {
    int x, y;
    cout << "Enter board size (N, maximum 20): ";
    cin >> N;

    if (N < 1 || N > MAX) {
        cout << "Invalid board size!" << endl;
        return 0;
    }

    cout << "Enter starting row and column (0 to "
         << N - 1 << "): ";
    cin >> x >> y;

    if (x < 0 || x >= N || y < 0 || y >= N) {
        cout << "Invalid starting position!" << endl;
        return 0;
    }

    // Initialize all squares as unvisited
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            board[i][j] = -1;
        }
    }

    // Mark the starting square as move 1
    board[x][y] = 1;

    if (solveKnightTour(x, y, 1)) {
        cout << "\nKnight's Tour found:\n";
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                cout.width(4);
                cout << board[i][j];
            }
            cout << endl;
        }
    } else {
        cout << "\nNo Knight's Tour found by the search."
             << endl;
    }
    return 0;
}