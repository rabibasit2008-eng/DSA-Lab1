#include <iostream>
#include <string>
using namespace std;

struct Node {
    char data;
    int freq;

    Node* left;
    Node* right;

    Node(char ch, int f) {
        data = ch;
        freq = f;
        left = nullptr;
        right = nullptr;
    }
};
//binary Min Heap
class MinHeap {
public:
    Node* heap[100];
    int size;

    MinHeap() {
        size = 0;
    }
    void insert(Node* node) {
        int i = size;
        heap[size] = node;
        size++;
        // Move node upwards
        while (i > 0) {
            int parent = (i - 1) / 2;

            if (heap[parent]->freq <= heap[i]->freq)
                break;
            swap(heap[parent], heap[i]);
            i = parent;
        }
    }
    Node* extractMin() {
        Node* minNode = heap[0];
        heap[0] = heap[size - 1];
        size--;
        int i = 0;
        // Move node downwards
        while (true) {
            int smallest = i;
            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if (left < size &&
                heap[left]->freq < heap[smallest]->freq) {
                smallest = left;
            }
            if (right < size &&
                heap[right]->freq < heap[smallest]->freq) {
                smallest = right;
            }
            if (smallest == i)
                break;
            swap(heap[i], heap[smallest]);
            i = smallest;
        }
        return minNode;
    }
};

//build Huffman Tree
Node* buildHuffmanTree(char S[], int f[], int n) {
    MinHeap h;

    //insert all characters into heap
    for (int i = 0; i < n; i++) {
        Node* newNode = new Node(S[i], f[i]);
        h.insert(newNode);
    }
    //combine two minimum frequency nodes
    while (h.size > 1) {
        Node* left = h.extractMin();
        Node* right = h.extractMin();
        Node* parent = new Node('\0',
                                left->freq + right->freq);

        parent->left = left;
        parent->right = right;
        h.insert(parent);
    }
    return h.extractMin();
}

//preorder traversal to print Huffman codes
void printCodes(Node* root, string code) {
    if (root == nullptr)
        return;
    //if leaf node, print character and code
    if (root->left == nullptr &&
        root->right == nullptr) {
        cout << root->data << " : " << code << endl;
        return;
    }
    printCodes(root->left, code + "0");
    printCodes(root->right, code + "1");
}
int main() {
    int n = 6;
    char S[] = {'a', 'b', 'c', 'd', 'e', 'f'};
    int f[] = {5, 9, 12, 13, 16, 45};
    Node* root = buildHuffmanTree(S, f, n);
    cout << "Huffman Codes:\n";
    printCodes(root, "");
    return 0;
}
