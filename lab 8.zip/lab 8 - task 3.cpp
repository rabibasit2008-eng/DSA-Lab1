#include <iostream>
#include <algorithm>
using namespace std;

bool maximize = true;
// AVL Node
struct Node {
    int id;
    int score;
    int height;
    Node* left;
    Node* right;
    Node(int i, int s) {
        id = i;
        score = s;
        height = 1;
        left = nullptr;
        right = nullptr;
    }
};
// Check which element is better
bool better(int s1, int id1, int s2, int id2) {
    if (s1 != s2) {
        if (maximize)
            return s1 > s2;

        return s1 < s2;
    }
    return id1 < id2;
}
// Get height
int getHeight(Node* root) {
    if (root == nullptr)
        return 0;

    return root->height;
}
// Calculate balance factor
int getBalance(Node* root) {
    if (root == nullptr)
        return 0;

    return getHeight(root->left) -
           getHeight(root->right);
}
// Right Rotation
Node* rightRotate(Node* y) {

    Node* x = y->left;
    Node* temp = x->right;

    x->right = y;
    y->left = temp;

    y->height = 1 + max(getHeight(y->left),
                        getHeight(y->right));

    x->height = 1 + max(getHeight(x->left),
                        getHeight(x->right));

    return x;
}
// Left Rotation
Node* leftRotate(Node* x) {

    Node* y = x->right;
    Node* temp = y->left;

    y->left = x;
    x->right = temp;

    x->height = 1 + max(getHeight(x->left),
                        getHeight(x->right));

    y->height = 1 + max(getHeight(y->left),
                        getHeight(y->right));

    return y;
}
// Insert a new element
Node* insert(Node* root, int id, int score) {

    if (root == nullptr)
        return new Node(id, score);

    if (better(score, id, root->score, root->id))
        root->left = insert(root->left, id, score);

    else if (better(root->score, root->id, score, id))
        root->right = insert(root->right, id, score);

    else
        return root;

    // Update height
    root->height = 1 + max(getHeight(root->left),
                           getHeight(root->right));

    int balance = getBalance(root);

    // LL Case
    if (balance > 1 &&
        better(score, id,
               root->left->score, root->left->id)) {
        return rightRotate(root);
    }
    // RR Case
    if (balance < -1 &&
        better(root->right->score, root->right->id,
               score, id)) {
        return leftRotate(root);
    }
    // LR Case
    if (balance > 1 &&
        better(root->left->score, root->left->id,
               score, id)) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }
    // RL Case
    if (balance < -1 &&
        better(score, id,
               root->right->score, root->right->id)) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}
// Find smallest node in tree ordering
Node* minValueNode(Node* root) {

    Node* temp = root;

    while (temp->left != nullptr)
        temp = temp->left;

    return temp;
}
// Delete an element
Node* deleteNode(Node* root, int id, int score) {

    if (root == nullptr)
        return root;

    if (better(score, id, root->score, root->id)) {
        root->left = deleteNode(root->left, id, score);
    }
    else if (better(root->score, root->id, score, id)) {
        root->right = deleteNode(root->right, id, score);
    }
    else {
        // No child or one child
        if (root->left == nullptr ||
            root->right == nullptr) {

            Node* temp;

            if (root->left != nullptr)
                temp = root->left;
            else
                temp = root->right;

            delete root;
            return temp;
        }
        // Two children
        Node* temp = minValueNode(root->right);

        root->id = temp->id;
        root->score = temp->score;

        root->right = deleteNode(
            root->right, temp->id, temp->score
        );
    }
    // Update height
    root->height = 1 + max(getHeight(root->left),
                           getHeight(root->right));
    int balance = getBalance(root);
    // LL
    if (balance > 1 && getBalance(root->left) >= 0)
        return rightRotate(root);
    // LR
    if (balance > 1 && getBalance(root->left) < 0) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }
    // RR
    if (balance < -1 && getBalance(root->right) <= 0)
       return leftRotate(root);
    // RL
    if (balance < -1 && getBalance(root->right) > 0) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}
// Update score
Node* update(Node* root, int id,
             int oldScore, int newScore) {

    root = deleteNode(root, id, oldScore);

    root = insert(root, id, newScore);

    return root;
}
// Print top K elements
void topK(Node* root, int k, int& count) {

    if (root == nullptr || count >= k)
        return;

    // Visit better-ranked elements first
    topK(root->left, k, count);

    if (count < k) {
        cout << "ID: " << root->id
             << " Score: " << root->score << endl;

        count++;
    }
    topK(root->right, k, count);
}
int main() {
    Node* root = nullptr;
    // true = maximum
    // false = minimum
    maximize = true;
    root = insert(root, 101, 40);
    root = insert(root, 102, 90);
    root = insert(root, 103, 20);
    root = insert(root, 104, 70);
    root = insert(root, 105, 60);

    cout << "Top 3 elements:\n";
    int count = 0;
    topK(root, 3, count);

    // Update ID 103 from 20 to 100
    root = update(root, 103, 20, 100);

    cout << "\nAfter updating:\n";
    count = 0;
    topK(root, 3, count);
    // Delete ID 102
    root = deleteNode(root, 102, 90);
    cout << "\nAfter deletion:\n";

    count = 0;
    topK(root, 3, count);

    return 0;
}