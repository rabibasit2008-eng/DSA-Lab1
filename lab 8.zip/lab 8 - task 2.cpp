#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;

    Node(int val) {
        data = val;
        next = nullptr;
    }
};
// Min Heap
class MinHeap {
public:
    Node* heap[100];
    int size;

    MinHeap() {
        size = 0;
    }

    void insert(Node* node) {
        int i = size;
        heap[size] = node;
        size++;

        while (i > 0) {
            int parent = (i - 1) / 2;

            if (heap[parent]->data <= heap[i]->data)
                break;

            swap(heap[parent], heap[i]);
            i = parent;
        }
    }

    Node* extractMin() {
        Node* smallest = heap[0];

        heap[0] = heap[size - 1];
        size--;

        int i = 0;
        while (true) {
            int left = 2 * i + 1;
            int right = 2 * i + 2;
            int smallestIndex = i;
            if (left < size &&
                heap[left]->data < heap[smallestIndex]->data) {
                smallestIndex = left;
            }
            if (right < size &&
                heap[right]->data < heap[smallestIndex]->data) {
                smallestIndex = right;
            }
            if (smallestIndex == i)
               break;
            swap(heap[i], heap[smallestIndex]);
            i = smallestIndex;
        }
        return smallest;
    }
};
// Merge K sorted linked lists
Node* mergeKLists(Node* lists[], int k) {
    MinHeap h;

    for (int i = 0; i < k; i++) {
        if (lists[i] != nullptr) {
            h.insert(lists[i]);
        }
    }
    Node dummy(0);
    Node *tail = &dummy;

    while (h.size > 0) {
        Node* smallest = h.extractMin();

        Node* nextNode = smallest->next;

        smallest->next = nullptr;

        tail->next = smallest;
        tail = smallest;

        if (nextNode != nullptr) {
            h.insert(nextNode);
        }
    }
    return dummy.next;
}

void display(Node* head) {
    while (head != nullptr) {
        cout << head->data << " -> ";
        head = head->next;
    }
    cout << "NULL\n";
}

int main() {

    Node* l1 = new Node(1);
    l1->next = new Node(4);
    l1->next->next = new Node(7);

    Node* l2 = new Node(2);
    l2->next = new Node(5);
    l2->next->next = new Node(8);

    Node* l3 = new Node(3);
    l3->next = new Node(6);
    l3->next->next = new Node(9);

    Node* lists[] = {l1, l2, l3};

    Node* result = mergeKLists(lists, 3);

    display(result);

    return 0;
}