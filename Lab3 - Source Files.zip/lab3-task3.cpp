#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};
Node* head = NULL;

// 1. Insert at head
void insertAtHead(int value) {
    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = head;
    head = newNode;
}

// 2. Insert at 3rd position
void insertAtThird(int value) {
    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = NULL;

    if (head == NULL) {                  
        head = newNode;
        cout << "List was empty, inserted as first node.\n";
    }
    else if (head->next == NULL) {      
        head->next = newNode;
        cout << "Only 1 node, inserted at the end.\n";
    }
    else {
        Node* second = head->next;       
        newNode->next = second->next;
        second->next = newNode;
    }
}

// 3. Display
void displayList() {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}

// 4. Delete last node
void deleteLast() {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }
    if (head->next == NULL) {         
        delete head;
        head = NULL;
    }
    else {
        Node* temp = head;
        while (temp->next->next != NULL) 
            temp = temp->next;
        delete temp->next;
        temp->next = NULL;
    }
    displayList();
}

// 5. Count nodes
int countNodes() {
    int count = 0;
    Node* temp = head;
    while (temp != NULL) {
        count++;
        temp = temp->next;
    }
    return count;
}

// 6. Reverse 
void reverseList() {
    Node* prev = NULL;
    Node* curr = head;
    Node* next = NULL;

    while (curr != NULL) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    head = prev;
    displayList();
}

// 7. Search
void searchValue(int value) {
    Node* temp = head;
    int index = 0;
    while (temp != NULL) {
        if (temp->data == value) {
            cout << value << " found at index " << index << "\n";
            return;
        }
        temp = temp->next;
        index++;
    }
    cout << value << " not found.\n";
}

// 8. Menu
int main() {
    int choice, value;

    do {
        cout << "\n1. Insert at head\n";
        cout << "2. Insert at 3rd position\n";
        cout << "3. Display\n";
        cout << "4. Delete last\n";
        cout << "5. Count nodes\n";
        cout << "6. Reverse\n";
        cout << "7. Search\n";
        cout << "8. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value: ";
                cin >> value;
                insertAtHead(value);
                break;
            case 2:
                cout << "Enter value: ";
                cin >> value;
                insertAtThird(value);
                break;
            case 3:
                displayList();
                break;
            case 4:
                deleteLast();
                break;
            case 5:
                cout << "Total nodes: " << countNodes() << "\n";
                break;
            case 6:
                reverseList();
                break;
            case 7:
                cout << "Enter value to search: ";
                cin >> value;
                searchValue(value);
                break;
            case 8:
                cout << "Goodbye!\n";
                break;
            default:
                cout << "Invalid choice.\n";
        }
    } while (choice != 8);

    return 0;
}