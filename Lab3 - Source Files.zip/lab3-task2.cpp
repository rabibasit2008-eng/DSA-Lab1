#include <iostream>
#include <string>
using namespace std;

class StringPool {
private:
    string* stringPool;  
    int currentSize;      
    int maxSize;          

public:
    StringPool() {
        maxSize = 5;
        currentSize = 0;

        stringPool = new string[maxSize];
    }

    void addString(string str) {
        if (currentSize < maxSize) {
            stringPool[currentSize] = str;
            currentSize++;
            cout << "Added: " << str << endl;
        }
        else {
            cout << "Pool is full!" << endl;
        }
    }

    void removeString(int index) {
        if (index >= 0 && index < currentSize) {
            cout << "Removing: " << stringPool[index] << endl;

            for (int i = index; i < currentSize - 1; i++) {
                stringPool[i] = stringPool[i + 1];
            }
            currentSize--;
        }
        else {
            cout << "Invalid index!" << endl;
        }
    }

    void displayPool() {
        cout << "\nCurrent Pool:\n";

        if (currentSize == 0) {
            cout << "Pool is empty." << endl;
            return;
        }
        for (int i = 0; i < currentSize; i++) {
            cout << i << ": " << stringPool[i] << endl;
        }
    }
    ~StringPool() {
        delete[] stringPool;
        stringPool = nullptr;

        cout << "\nMemory successfully freed." << endl;
    }
};

int main() {
    StringPool pool;
    pool.addString("Apple");
    pool.addString("Banana");
    pool.addString("Orange");
    pool.addString("Mango");
    pool.addString("Grapes");

    pool.displayPool();

    pool.removeString(1);   
    pool.removeString(2);  
    pool.displayPool();

    cout << "\nProgram ending..." << endl;
    cout << "Destructor will now free the allocated memory." << endl;

    return 0;
}