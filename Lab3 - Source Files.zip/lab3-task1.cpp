#include <iostream>
#include <string>
using namespace std;

int main(){
    string word;
    bool isPalindrome = true;
    cout << "Enter any word: \n" ;
    cin >> word;

    int start = 0;
    int end = word.length() - 1;

    while(start < end){
        if(word[start] != word[end]){
            isPalindrome = false;
            break;
        }
        start++;
        end--;
    }
    if(isPalindrome){
        cout << word << " is a palindrome word.\n";
    }
    else{
        cout << word << " is not a palindrome word.\n";
    }
    return 0;
}